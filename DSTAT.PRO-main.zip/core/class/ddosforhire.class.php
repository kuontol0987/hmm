<?php

/*----------------------------------
	============================
	Website: DSTAT.PRO
	Author: RootSec
	Website url: https://dstat.pro/
	============================
-----------------------------------*/

class dfh {

    public function searchusers($user) {
        global $DataBase;

		$DataBase->Query("SELECT id, username FROM `users` WHERE `username` LIKE ?");
		$DataBase->Bind(1, "%$user%", PDO::PARAM_STR);
		$DataBase->Execute();
        return $DataBase->ResultSet();
    }
    
    public function submitsite($site, $desc, $link, $oid, $l3l4, $l7, $logs, $api, $payment) {
        global $DataBase;
		global $Logs;
		

        $DataBase->Query("INSERT INTO `users` (`id`, `site`, `description`, `link`, `ownerid`, `l3l4`, `l7`, `logging`, `api`, `payment`, `status`, `lmodified`) VALUES (NULL, :Site, :Desc, :Link, :Oid, :l3l4, :l7, :logging, :api, :payment, :status, :lmodified);");
		$DataBase->Bind(':Site', $site);
		$DataBase->Bind(':Desc', $desc);
		$DataBase->Bind(':Link', $link);
		$DataBase->Bind(':oid', $oid);     
        $DataBase->Bind(':l3l4', $l3l4);     
		$DataBase->Bind(':l7', $l7);     
		$DataBase->Bind(':logging', $logs);     
		$DataBase->Bind(':api', $api);     
    	$DataBase->Bind(':payment', $payment);     
		$DataBase->Bind(':status', 0);     
		$DataBase->Bind(':lmodified', time());     

		if(!$DataBase->Execute()) {
			return false;
		} else {
			return true;
		}
    }
    
    public function modifysite() {
        
    }
    
    public function deletesite() {
        
    }
}