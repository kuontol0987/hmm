<?php

/*----------------------------------
	============================
	Website: stresserit.pro
	Author: Hazze
	Website url: https://stresserit.pro/
	============================
-----------------------------------*/

class News {

	/* Get all News */
	public function getAllNews() {
		global $DataBase;

		$DataBase->Query("SELECT * FROM `news` ORDER by `id` DESC");
		$DataBase->Execute();

		return $DataBase->ResultSet();
	}

	/* add news */
	public function addNews($Title, $Text) {
		global $DataBase;

		$DataBase->Query("INSERT INTO `news` (`id`, `title`, `text`, `date`) VALUES (NULL, :Title, :Tekst, :Timestamp);");
		$DataBase->Bind(':Title', $Title);
		$DataBase->Bind(':Tekst', $Text);
		$DataBase->Bind(':Timestamp', time());

		if(!$DataBase->Execute()) {
            return false;
        } else {
            return true;
        }
	}

	public function modifyNews($ID, $Title, $Text) {
		global $DataBase;

		$DataBase->Query("UPDATE `news` SET `title`=:Title, `text`=:Text WHERE `id`=:ID");
		$DataBase->Bind(':Title', $Title);
		$DataBase->Bind(':Text', $Text);
		$DataBase->Bind(':ID', $ID);

		if(!$DataBase->Execute()) {
            return false;
        } else {
            return true;
        }
	}

	public function NewsDataAll() {
		global $DataBase;

		$DataBase->Query("SELECT * FROM `news` ORDER BY `id` DESC");
		$DataBase->Execute();

		$Return = array(
			'Count' => $DataBase->RowCount(),
			'Response' => $DataBase->ResultSet()
		);

		return $Return;
	}


	

	
	public function DeleteNews($id) {
		global $DataBase;

		$DataBase->Query("DELETE FROM `news` WHERE `id`=:uID");
		$DataBase->Bind(':uID', $id);

		return $DataBase->Execute();
	}

	public function CountNewsByID($userID) {
		global $DataBase;

		$DataBase->Query("SELECT * FROM `news` WHERE `id` = :ID");
		$DataBase->Bind(':ID', $userID);
		$DataBase->Execute();

		$nArr = Array(
			'Count' 	=> $DataBase->RowCount()
		);
		return $nArr;
	}


	public function NewsDataID($id, $num) {
		global $DataBase;

		$DataBase->Query("SELECT * FROM `news` WHERE `id` = :ID");
		$DataBase->Bind(':ID', $id);
		$DataBase->Execute();

		if($num == 0) {
			$Return = array(
				'Count' => $DataBase->RowCount(),
				'Response' => $DataBase->ResultSet()
			);
	
			return $Return;
		} else {
			return $DataBase->Single();
		}
	}

}