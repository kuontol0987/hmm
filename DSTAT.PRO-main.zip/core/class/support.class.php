<?php

/*----------------------------------
	============================
	Website: stresserit.pro
	Author: Hazze
	Website url: https://stresserit.pro/
	============================
-----------------------------------*/

// error_reporting(0);

class Support {

	/* Ticket List */
	public function ticketsList($userID) {
		global $DataBase;

		$DataBase->Query("SELECT * FROM `tickets` WHERE `userID` = :userID ORDER by `id` DESC");
		$DataBase->Bind(':userID', $userID);
		$DataBase->Execute();

		$Return = Array(
			'Response' 	=> $DataBase->ResultSet(),
			'Count' 	=> $DataBase->RowCount(),
		);
		return $Return;
	}


	/* Ticket List */
	public function ticketsListAll() {
		global $DataBase;

		$DataBase->Query("SELECT * FROM `tickets` ORDER by `id` DESC");
		$DataBase->Execute();

		$Return = Array(
			'Response' 	=> $DataBase->ResultSet(),
			'Count' 	=> $DataBase->RowCount(),
		);
		return $Return;
	}

	/* New Ticket */
	public function newTicket($Title, $Message, $userID) {
		global $DataBase;

		$DataBase->Query("INSERT INTO `tickets` (`id`, `title`, `message`, `status`, `date`, `userID`, `lastactivity`) VALUES (NULL, :Title, :Message, :Status, :Date, :userID, :lastactivity);");
		$DataBase->Bind(':Title', $Title);
		$DataBase->Bind(':Message', $Message);
		$DataBase->Bind(':Status', '2');
		$DataBase->Bind(':Date', time());
		$DataBase->Bind(':userID', $userID);
		$DataBase->Bind(':lastactivity', time());

		return $DataBase->Execute();
	}

	
	public function ticketStatusToBadge($status) {
		if($status == 0) {

		} else if ($status == 1) {
			$return = array('<span style="color:#38b44a;" class="fa fa-circle m-r-10"></span>', 'Answered');
		} else if ($status == 2) {
			$return = array('<span style="color:#ffaa00;" class="fa fa-circle m-r-10"></span>', 'Waiting for admin response');
		} else if ($status == 3) {
			$return = array('<span style="color:#bc271c;" class="fa fa-circle m-r-10"></span>', 'Ticket is closed');
		} else {
			$return = '<span class="fa fa-circle m-r-10"></span>';
		}

		return $return;
	}
	/* Ticket By ID */
	public function ticketByID($tID, $userID) {
		global $DataBase;

		$DataBase->Query("SELECT * FROM `tickets` WHERE `id` = :tID AND `userID` = :userID");
		$DataBase->Bind(':tID', $tID);
		$DataBase->Bind(':userID', $userID);
		$DataBase->Execute();

		return $DataBase->Single();
	}

	/* Ticket By ID */
	public function ticketByIDAdmin($tID, $userID) {
		global $DataBase;

		$DataBase->Query("SELECT * FROM `tickets` WHERE `id` = :tID AND `userID` = :userID");
		$DataBase->Bind(':tID', $tID);
		$DataBase->Bind(':userID', $userID);
		$DataBase->Execute();

		$Return = Array(
			'Response' 	=> $DataBase->ResultSet(),
			'Count' 	=> $DataBase->RowCount(),
		);
		return $Return;
	}

	/* Ticket By ID */
	public function ticketByIDSingle($tID, $userID) {
		global $DataBase;

		$DataBase->Query("SELECT * FROM `tickets` WHERE `id` = :tID AND `userID` = :userID");
		$DataBase->Bind(':tID', $tID);
		$DataBase->Bind(':userID', $userID);
		$DataBase->Execute();

		return $DataBase->Single();
	}

	/* Ticket Status */
	public function ticketStatus($Status) {
		if (isset($Status) && empty($Status)) {
			$nArr = ['red', 'Unknown'];
		} else if($Status == '1') {
			$nArr = ['#ffc107', 'Waiting for admin answer'];
		} else if($Status == '2') {
			$nArr = ['#26ff26', 'Waiting for your answer'];
		} else if($Status == '3') {
			$nArr = ['red', 'Closed'];
		}
		return $nArr;
	}

	/* Get all tickets by userID */
	public function onlyByNotClosed($userID) {
		global $DataBase;

		$DataBase->Query("SELECT * FROM `tickets` WHERE `userID` = :userID AND `Status` != '3';");
		$DataBase->Bind(':userID', $userID);
		$DataBase->Execute();

		$nArr = Array(
			'Response' 	=> $DataBase->ResultSet(),
			'Count' 	=> $DataBase->RowCount()
		);
		return $nArr;
	}

	/* Ticket Priority */
	public function ticketPriority($Priority) {
		if (isset($Priority) && empty($Priority)) {
			$nArr = ['red', 'Priority?'];
		} else if($Priority == '1') {
			$nArr = ['#26ff26', 'Normal'];
		} else if($Priority == '2') {
			$nArr = ['#ffc107', 'Medium'];
		} else if($Priority == '3') {
			$nArr = ['red', 'Urgent'];
		}
		return $nArr;
	}

	/* Add Answer */
	public function answOnTicket($tID, $userID, $supportID, $Message) {
		global $DataBase;

		$DataBase->Query("INSERT INTO `ticket_answ` (`id`, `tID`, `userID`, `supportID`, `Message`, `Date`, `lastactivity`) VALUES (NULL, :tID, :userID, :supportID, :Message, :Date, :lastactivity);");
		$DataBase->Bind(':tID', $tID);
		$DataBase->Bind(':userID', $userID);
		$DataBase->Bind(':supportID', $supportID);
		$DataBase->Bind(':Message', $Message);
		$DataBase->Bind(':Date', time());
		$DataBase->Bind(':lastactivity', time());

		return $DataBase->Execute();
	}

	/* Update Ticket */
	public function upStatusOnTicket($tID, $Status) {
		global $DataBase;
		
		$DataBase->Query("UPDATE `tickets` SET `Status` = :Status WHERE `id` = :tID;");
		$DataBase->Bind(':tID', $tID);
		$DataBase->Bind(':Status', $Status);

		return $DataBase->Execute();
	}

	/* Answer on Ticket list */
	public function answOnTicketList($tID) {
		global $DataBase;

		$DataBase->Query("SELECT * FROM `ticket_answ` WHERE `tID` = :tID ORDER by id ASC");
		$DataBase->Bind(':tID', $tID);
		$DataBase->Execute();

		return $DataBase->ResultSet();
	}


}